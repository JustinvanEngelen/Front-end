// Array met de dagen van de week
var dagenVanDeWeek = ["maandag", "dinsdag", "woensdag", "donderdag", "vrijdag", "zaterdag", "zondag"];

// Functie om de dagen weer te geven
function toonDagen() {
    document.getElementById("alleDagen").innerText = dagenVanDeWeek.join(", ");
    document.getElementById("werkdagen").innerText = dagenVanDeWeek.slice(0, 5).join(", ");
    document.getElementById("weekenddagen").innerText = dagenVanDeWeek.slice(5).join(", ");
    document.getElementById("omgekeerdeAlleDagen").innerText = dagenVanDeWeek.slice().reverse().join(", ");
    document.getElementById("omgekeerdeWerkdagen").innerText = dagenVanDeWeek.slice(0, 5).reverse().join(", ");
    document.getElementById("omgekeerdeWeekenddagen").innerText = dagenVanDeWeek.slice(5).reverse().join(", ");
}

// Roep de functie aan om de dagen weer te geven
toonDagen();